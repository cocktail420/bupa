
 <main id="main">
 <!-- ======= Testimonials Section ======= -->
  
        
    <section id="contact">
      <div class="container" data-aos="fade-up">
        <div class="section-header">
          <center><h3>BUPA Registration Form</h3></center>
          <!--<p></p>-->
        </div>


      </div>



      <div class="container">
        <div class="form">
          <form action="<?= base_url().'Welcome/Join' ?>" method="post" role="form" >
            <div class="row">
              <div class="form-group col-md-6">
                <input type="text" name="firstname" class="form-control"  placeholder="Your Firstname" required>
              </div>
              <div class="form-group col-md-6 mt-3 mt-md-0">
                <input type="text" class="form-control" name="lastname"  placeholder="Your lastname" required>
              </div>
            </div><br>
            
               <div class="row">
              <div class="form-group col-md-6">
                <input type="text" name="surname" class="form-control" id="surname" placeholder="Your surname" required>
              </div>
              <div class="form-group col-md-6">

                <select name="agegroup" class="form-control"  placeholder="Age group" required>
                    <option value="">Select age group</option>
                    <option value="1">18 to 35</option>
                    <option value="2">35 to 70</option>
                </select>
              </div>
            </div><br>
            
               <div class="row">
              <div class="form-group col-md-6">
                <input type="text" name="profession" class="form-control" placeholder="Your profession" required>
              </div>
              <div class="form-group col-md-6 mt-3 mt-md-0">
                <input type="number" class="form-control" name="telephone"  placeholder="Your telephone" required>
              </div>
            </div><br>
            
               <div class="row">
              <div class="form-group col-md-6">
                <input type="text" name="address" class="form-control"  placeholder="Address P.O BOX" required>
              </div>
              <div class="form-group col-md-6 mt-3 mt-md-0">
                <input type="text" class="form-control" name="code"  placeholder="Code" required>
              </div>
            </div><br>
            
            
               <div class="row">
              
              <div class="form-group col-md-6 mt-3 mt-md-0">
                <input type="text" class="form-control" name="city" placeholder="Your City/Town" required>
              </div>
              <div class="form-group col-md-6">
                <input type="email" name="email" class="form-control"  placeholder="Email address" required>
              </div>
            </div><br>
            
            
               <div class="row">
              <div class="form-group col-md-6">
                <input type="text" name="company" class="form-control"  placeholder="Company/Organisation name" required>
              </div>
              <div class="form-group col-md-6 mt-3 mt-md-0">
                <input type="text" class="form-control" name="street" id="email" placeholder="Road/Street/Avenue" required>
              </div>
            </div><br>
            
            
               <div class="row">
              <div class="form-group col-md-6">
                <input type="text" name="businessbox" class="form-control" placeholder="Business P.O Box " required>
              </div>
              <div class="form-group col-md-6 mt-3 mt-md-0">
                <input type="text" class="form-control" name="businesscode" placeholder="Business code" required>
              </div>
            </div><br>
            
            
               <div class="row">
              <div class="form-group col-md-6">
                <input type="text" name="businesscity" class="form-control"  placeholder="Business City/Town" required>
              </div>
              <div class="form-group col-md-6 mt-3 mt-md-0">
                <input type="text" class="form-control" name="constituency"  placeholder="Constituency" required>
              </div>
            </div><br>
            
            <!-- <div class="row">-->
            <!--  <div class="form-group col-md-6">-->

            <!--    <select name="agegroup" class="form-control"  placeholder="Age group" required>-->
            <!--        <option value="">Select age group</option>-->
            <!--        <option value="1">18 to 35</option>-->
            <!--        <option value="2">35 to 70</option>-->
            <!--    </select>-->
            <!--  </div>-->
            
            <!--</div><br>-->
            
          

            <!--<div class="my-3">-->
            <!--  <div class="loading">Loading</div>-->
            <!--  <div class="error-message"></div>-->
            <!--  <div class="sent-message">Your message has been sent. Thank you!</div>-->
            <!--</div>-->

            <div class="text-center"><button type="submit">Join</button></div>
          </form>
        </div>

      </div>
    </section><!-- End Contact Section -->


      </div>
    </section>
    </main>
    
