

  <main id="main">



       <!-- ======= About Section ======= -->
    <section id="about">
      <!--<div class="container" data-aos="fade-up">-->
           <div class="section-header">
         <center><h2>ABOUT US</h2></center> 
        
        </div>
        <div class="row">
        

          <div class="col-lg-6 content">
            <h3>BUPA Was Founded Sit Amet Consectetur Adipisicing Elit. Distinctio Laborum Aliquam Fuga Enim, Eaque Pariatur Mollitia Odio Illum Incidunt, Recusandae Atque Veniam Quia, Debitis Officia Temporibus Ducimus Esse. Aliquid, Fuga.:</h3>

            <ul>
              <li><p>Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Aperiam Vero, Ipsum Eius Vel Voluptate Placeat Adipisci Consectetur Tenetur Aliquam, Natus Asperiores Neque Earum Vitae Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Dolorem Iste Amet Quia Autem Doloribus Nihil Fuga Odit Quam Animi. Iste Est Quia Beatae Dolorum Ad Eos Culpa Assumenda Quas Ipsum. Maiores Perferendis Voluptatum Ex Provident. Quaerat!
                </p></li>
                
                <li><button>Our History</button></li>
            </ul>
          

          </div>
          
          
          
            <div class="col-lg-5 about-img">
            <img src="<?= base_url().'assets/img/about.jpeg' ?>" alt="">
          </div>
          
          
        </div>

      <!--</div>-->
    </section>
    <!-- End About Section -->


  </main><!-- End #main -->

